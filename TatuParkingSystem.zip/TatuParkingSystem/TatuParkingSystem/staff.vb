﻿Imports MySql.Data.MySqlClient
Public Class staff

    Dim MyString As String = "Server=localhost;user id = root;password = '';Database = tatuDB;Port=3306 "
    Dim SQLconnection As MySqlConnection = New MySqlConnection
    Dim SQLStatement As String
    Dim dr As MySqlDataReader
    Dim sda As MySqlDataAdapter
    Dim table As DataTable

    Dim userid As Integer
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub
    Private Sub ListView1_Click(sender As Object, e As EventArgs) Handles ListView1.Click

        txtfname.Text = Me.ListView1.SelectedItems(0).SubItems(2).Text
        txtlname.Text = Me.ListView1.SelectedItems(0).SubItems(3).Text
        txtemail.Text = Me.ListView1.SelectedItems(0).SubItems(4).Text
        txtphone.Text = Me.ListView1.SelectedItems(0).SubItems(5).Text
        cbdepartment.Text = Me.ListView1.SelectedItems(0).SubItems(6).Text


    End Sub
    Private Sub randomGen()
        Dim randoms(1234) As Integer
        Dim Random_Number As Random = New Random()
        userid = Random_Number.Next()

    End Sub

    Private Sub staff_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If (SQLconnection.State = ConnectionState.Open) Then
            SQLStatement = "SELECT * FROM staff"
            acounts_load_data()

        Else
            SQLconnection.ConnectionString = MyString
            SQLconnection.Open()
            'MsgBox("Database connection is closed")
            SQLStatement = "SELECT * FROM staff"
            acounts_load_data()

        End If

    End Sub

    Private Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click

        If txtfname.Text = "" Then
            MsgBox("Please the field cannot be empty")

        ElseIf txtlname.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtemail.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtphone.Text = "" Then
            MsgBox("Please the field cannot be empty")

            MsgBox("Please the field cannot be empty")
        ElseIf txtlname.Text = "" Then
            MsgBox("Please the field cannot be empty")

        Else
            randomGen()
            staff_check()

            Try
                If txtlname.Text <> "" Then
                    SQLStatement = " INSERT INTO staff(Staff_ID,First_Name,Last_Name,Email,Phone_Number,Department_ID)
                                  VALUES('" & userid & "','" & txtfname.Text & "', '" & txtlname.Text & "','" & txtemail.Text & "','" & txtphone.Text & "','" & cbdepartment.Text & "')"
                    Saverecords(SQLStatement)
                    MsgBox("Account Created Successful")

                    SQLStatement = "SELECT * FROM staff"
                    acounts_load_data()
                Else

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                '
                txtlname.Clear()
                txtphone.Clear()
                txtemail.Clear()

                txtfname.Clear()
                cbdepartment.Text = ""

            End Try

        End If

    End Sub

    Private Sub Saverecords(ByRef SQLStatement As String)
        Try

            Dim cmd As MySqlCommand = New MySqlCommand
            With cmd
                .CommandText = SQLStatement
                .CommandType = CommandType.Text
                .Connection = SQLconnection
                .ExecuteNonQuery()
            End With


        Catch ex As Exception
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()
            Else
                MsgBox(ex.Message)
            End If

        End Try
    End Sub


    Private Sub acounts_load_data()

        Try
            ListView1.Items.Clear()

            Dim command As New MySqlCommand(SQLStatement, SQLconnection)
            dr = command.ExecuteReader
            While dr.Read

                Dim i As Integer
                Dim lst As New ListViewItem(i)

                lst.SubItems.Add(dr.Item("Staff_ID"))
                lst.SubItems.Add(dr.Item("First_Name"))
                lst.SubItems.Add(dr.Item("Last_Name"))
                lst.SubItems.Add(dr.Item("Email"))
                lst.SubItems.Add(dr.Item("Phone_Number"))
                lst.SubItems.Add(dr.Item("Department_ID"))

                ListView1.Items.Add(lst)
            End While
            dr.Close()

        Catch ex As Exception
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally

        End Try

    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        accouts_delete_data()
    End Sub
    Private Sub accouts_delete_data()
        If txtlname.Text <> "" Then
            txtlname.Text = ListView1.SelectedItems(0).SubItems(5).Text

            Dim msg As Integer
            msg = MsgBox("Are You Sure You Want Delete This staff", vbYesNo + vbQuestion, "Information Deleting")

            If msg = 6 Then
                SQLStatement = "DELETE FROM staff Where Phone_Number = '" & ListView1.SelectedItems(0).SubItems(5).Text & "'"
                Try
                    Saverecords(SQLStatement)
                    MsgBox("Account Deleted Successful")
                    SQLStatement = "SELECT * FROM staff"
                    acounts_load_data()
                Catch ex As Exception
                Finally
                End Try
            End If
        Else
            MsgBox("Select the row you want to delete! ")

        End If
    End Sub

    Private Sub accout_updata_data()
        Try

            SQLStatement = "UPDATE staff SET First_Name ='" & txtfname.Text & "',Last_Name ='" & txtlname.Text & "',Email='" & txtemail.Text & "', Phone_Number = '" & txtphone.Text & "', Department_ID = '" & cbdepartment.Text & "'
             WHERE Phone_Number = '" & txtphone.Text & "'"
            Saverecords(SQLStatement)

            MsgBox("Update Successful!")
            SQLStatement = "SELECT * FROM staff"
            acounts_load_data()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

            txtlname.Clear()
            txtphone.Clear()
            txtemail.Clear()


            txtlname.Clear()
        End Try
        Exit Sub
    End Sub

    Private Sub staff_check()
        Try

            SQLStatement = "SELECT Email,Phone_Number FROM staff WHERE Email ='" & txtemail.Text & "' OR Phone_Number ='" & txtphone.Text & "'"
            Dim Command = New MySqlCommand(SQLStatement, SQLconnection)
            dr = Command.ExecuteReader

            If dr.Read Then
                dr.Close()
                MsgBox("Account already exist")
                Exit Sub
            Else
                dr.Close()

            End If

        Catch ex As Exception
            dr.Close()
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally
            '   
        End Try
    End Sub
    Private Sub check_data()
        Try


            Dim Command = New MySqlCommand(SQLStatement, SQLconnection)
            dr = Command.ExecuteReader

            If dr.Read Then
                dr.Close()
                SQLStatement = "SELECT * FROM staff"
                acounts_load_data()
            Else
                dr.Close()
                MsgBox("No data found on the system!")


            End If

        Catch ex As Exception
            dr.Close()
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally
            '   
        End Try
    End Sub
    Private Sub account_search_data()
        Try
            SQLStatement = "SELECT* FROM staff WHERE Phone_Number LIKE'" & txtsearch.Text & "%' OR Email LIKE'" & txtsearch.Text & "%' or Department_ID LIKE'" & txtsearch.Text & "%'"
            acounts_load_data()
        Catch ex As Exception
            MsgBox(ex.Message)
            txtsearch.Clear()
            txtsearch.Focus()
        Finally

        End Try
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        accout_updata_data()
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        SQLStatement = "SELECT*  FROM staff"
        check_data()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        activity.Show()
    End Sub
End Class