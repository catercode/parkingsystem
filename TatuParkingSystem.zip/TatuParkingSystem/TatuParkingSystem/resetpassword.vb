﻿Imports MySql.Data.MySqlClient
Public Class resetpassword
    Dim MyString As String = "Server=localhost;user id = root;password = '';Database = tatuDB;Port=3306 "
    Dim SQLconnection As MySqlConnection = New MySqlConnection
    Dim SQLStatement As String
    Dim dr As MySqlDataReader
    Dim sda As MySqlDataAdapter
    Dim table As DataTable
    Private Sub resetpassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If (SQLconnection.State = ConnectionState.Open) Then


        Else
            SQLconnection.ConnectionString = MyString
            SQLconnection.Open()


        End If
    End Sub

    Private Sub chechphone()

        Try
            SQLStatement = "SELECT Phone_Number,Email FROM useracount WHERE Phone_Number='" & txtphone.Text & "' OR Email='" & txtphone.Text & "'"
            Dim Command = New MySqlCommand(SQLStatement, SQLconnection)
            dr = Command.ExecuteReader

            If dr.Read Then
                dr.Close()
                Label6.Text = ("Phone verified")
                BunifuTransition1.ShowSync(Panel3)

                Timer1.Start()

            Else
                dr.Close()
                Label6.Text = (" Phone verification failed")
                Label6.ForeColor = Color.Red
                BunifuTransition1.ShowSync(Panel3)
                Timer1.Start()


            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally


        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        BunifuTransition1.HideSync(Panel3)
        Timer1.Stop()
    End Sub

    Private Sub txtphone_TextChanged(sender As Object, e As EventArgs) Handles txtphone.TextChanged

    End Sub

    Private Sub txtphone_LostFocus(sender As Object, e As EventArgs) Handles txtphone.LostFocus

    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        If txtphone.Text = "" Then
            Label6.Text = (" Please enter your phone number")
            Label6.ForeColor = Color.Red
            BunifuTransition1.ShowSync(Panel3)
            Timer1.Start()
        Else

            SQLStatement = "UPDATE useracount SET Password ='" & txtpassword.Text & "' WHERE Phone_Number='" & txtphone.Text & "'"

            Saverecords(SQLStatement)
            Label6.Text = (" Password reset successful")

            BunifuTransition1.ShowSync(Panel3)
            Timer1.Start()
        End If


    End Sub

    Private Sub Saverecords(ByRef SQLStatement As String)
        Try

            Dim cmd As MySqlCommand = New MySqlCommand
            With cmd
                .CommandText = SQLStatement
                .CommandType = CommandType.Text
                .Connection = SQLconnection
                .ExecuteNonQuery()
            End With


        Catch ex As Exception
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()
            Else
                MsgBox(ex.Message)
            End If

        End Try
    End Sub

    Private Sub txtphone_Leave(sender As Object, e As EventArgs) Handles txtphone.Leave
        chechphone()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class