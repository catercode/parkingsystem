﻿Imports System.Security.Cryptography
Imports System.Text
Imports MySql.Data.MySqlClient
Imports System.Drawing.Printing
Public Class activity

    Dim MyString As String = "Server=localhost;user id = root;password = '';Database = tatuDB;Port=3306 "
    Dim SQLconnection As MySqlConnection = New MySqlConnection
    Dim SQLStatement As String
    Dim dr As MySqlDataReader
    Dim sda As MySqlDataAdapter
    Dim table As DataTable

    Dim userid As Integer
    Private WithEvents p_Document As PrintDocument = Nothing


    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

    End Sub

    Private Sub ListView1_Click(sender As Object, e As EventArgs) Handles ListView1.Click


        lblPID.Text = Me.ListView1.SelectedItems(0).SubItems(1).Text
        lblOID.Text = Me.ListView1.SelectedItems(0).SubItems(2).Text
        cbasset.Text = Me.ListView1.SelectedItems(0).SubItems(3).Text
        txtregisNumber.Text = Me.ListView1.SelectedItems(0).SubItems(4).Text

        txtOname.Text = Me.ListView1.SelectedItems(0).SubItems(5).Text

        txtphone.Text = Me.ListView1.SelectedItems(0).SubItems(6).Text
        lbldate.Text = Me.ListView1.SelectedItems(0).SubItems(7).Text
        lbltime.Text = Me.ListView1.SelectedItems(0).SubItems(8).Text
        cbstatus.Text = Me.ListView1.SelectedItems(0).SubItems(9).Text

    End Sub
    Private Sub randomGen()

        Dim Random_Number As Random = New Random()
        userid = Random_Number.Next(12345)


    End Sub

    Private Sub Saverecords(ByRef SQLStatement As String)
        Try

            Dim cmd As MySqlCommand = New MySqlCommand
            With cmd
                .CommandText = SQLStatement
                .CommandType = CommandType.Text
                .Connection = SQLconnection
                .ExecuteNonQuery()
            End With


        Catch ex As Exception
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()
            Else
                MsgBox(ex.Message)
            End If

        End Try
    End Sub
    Private Sub trans_resit()

        txtreceit.AppendText(vbNewLine)
        txtreceit.AppendText("    " + " Park ID: #" & lblPID.Text & vbTab & vbTab & "Status: " & cbstatus.Text & vbNewLine & vbNewLine)
        txtreceit.AppendText(vbTab + System.DateTime.Now.ToString("dd/MM/yyyy") & vbTab & System.DateTime.Now.ToString("hh:mm:ss") & vbNewLine)
        txtreceit.AppendText("  " & vbNewLine)
        txtreceit.AppendText("  " & vbNewLine)
        txtreceit.AppendText("     " + "Owner ID: " & vbTab & vbTab & lblOID.Text & vbNewLine)
        txtreceit.AppendText("     " + "Owner Name: " & vbTab & vbTab & txtOname.Text & vbNewLine)
        txtreceit.AppendText("     " + "Phone Number: " & vbTab & vbTab & txtphone.Text & vbNewLine)

        txtreceit.AppendText(" " + "------------------------------------------------------------------------------------" & vbNewLine)


        txtreceit.AppendText("    " + "Registration No: " & vbTab & txtregisNumber.Text & vbNewLine)
        txtreceit.AppendText("    " + "Parking Log: " & vbTab & "1" & vbNewLine)
        txtreceit.AppendText("    " + "Parking No: " & vbTab & "1 " & vbNewLine)

        txtreceit.AppendText("  " & vbNewLine)

        txtreceit.AppendText(" " + "------------------------------------------------------------------------------------" & vbNewLine)
        txtreceit.AppendText("  " & vbNewLine)

        txtreceit.AppendText("    " + "THANK YOU FOR USING OUR PARKING LOG" & vbNewLine)



    End Sub

    Private Sub Selectprinterthanprint()

        p_Document = New PrintDocument

        'Hide print dialog
        Dim printControl = New StandardPrintController
        p_Document.PrintController = printControl
        AddHandler p_Document.PrintPage, AddressOf HandleOnPrintPages
        p_Document.Print()

    End Sub
    Dim more As Boolean = False

    Private Sub HandleOnPrintPages(ByVal sender As Object, ByVal e As PrintPageEventArgs) Handles p_Document.PrintPage
        On Error Resume Next
        Dim pr As Integer = 0
        pr = 50
        e.Graphics.DrawString(vbTab & "TaTU PARKING  SYSTEM", New Drawing.Font("Berlin Sans FB Demi", 11), Brushes.Black, 50, pr)
        pr += 20
        e.Graphics.DrawString(vbTab & "NORTHERN,TAMALE", New Drawing.Font("Consolas", 9), Brushes.Black, 50, pr)
        pr += 12
        e.Graphics.DrawString(vbTab & "  P.O.BOX 1223 TL", New Drawing.Font("Consolas", 9), Brushes.Black, 50, pr)
        pr += 12
        e.Graphics.DrawString(vbTab & "   TEL: 0345678934", New Drawing.Font("Consolas", 9), Brushes.Black, 50, pr)
        pr += 10
        e.Graphics.DrawString("_________________________________________________________", New Drawing.Font("Berlin Sans FB Demi", 9), Brushes.Black, 10, pr)
        pr += 20

        e.Graphics.DrawString(txtreceit.Text, New Drawing.Font("Consolas", 10), Brushes.Black, 0, pr)
        If more Then
            e.HasMorePages = True
        Else
            e.HasMorePages = False
        End If
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub activity_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If (SQLconnection.State = ConnectionState.Open) Then
            SQLStatement = "SELECT * FROM parking"
            park_load_data()

        Else
            SQLconnection.ConnectionString = MyString
            SQLconnection.Open()

            SQLStatement = "SELECT * FROM parking"
            park_load_data()

        End If

        systimer.Start()

    End Sub

    Private Sub btnpark_Click(sender As Object, e As EventArgs) Handles btnpark.Click
        If cbasset.Text = "" Then
            MsgBox("Please the field cannot be empty")

        ElseIf txtOname.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtregisNumber.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtphone.Text = "" Then
            MsgBox("Please the field cannot be empty")

            MsgBox("Please the field cannot be empty")
        ElseIf cbstatus.Text = "" Then
            MsgBox("Please the field cannot be empty")

        Else
            randomGen()

            Try
                If txtphone.Text <> "" Then
                    SQLStatement = " INSERT INTO parking(Park_ID,Owner_ID,Asset,Owner_Name,Phone_Number,Registration_No,Date,Time,Status)
                                  VALUES('" & lblPID.Text & "','" & lblOID.Text & "', '" & cbasset.Text & "','" & txtOname.Text & "','" & txtphone.Text & "','" & txtregisNumber.Text & "','" & lbldate.Text & "','" & lbltime.Text & "','" & cbstatus.Text & "')"
                    Saverecords(SQLStatement)
                    MsgBox("Parking is done")
                    trans_resit()
                    '  Selectprinterthanprint()
                    SQLStatement = "SELECT * FROM parking"
                    park_load_data()

                    lblPID.Text = ""
                    lblOID.Text = ""
                    cbasset.Text = ""
                    txtregisNumber.Clear()
                    lbldate.Text = ""
                    lbltime.Text = ""
                    txtOname.Clear()

                    txtphone.Clear()
                    cbstatus.Text = ""

                Else

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally


            End Try

        End If


    End Sub



    Private Sub park_load_data()

        Try
            ListView1.Items.Clear()

            Dim command As New MySqlCommand(SQLStatement, SQLconnection)
            dr = command.ExecuteReader
            While dr.Read

                Dim i As Integer
                Dim lst As New ListViewItem(i)

                lst.SubItems.Add(dr.Item("Park_ID"))
                lst.SubItems.Add(dr.Item("Owner_ID"))
                lst.SubItems.Add(dr.Item("Asset"))
                lst.SubItems.Add(dr.Item("Registration_No"))
                lst.SubItems.Add(dr.Item("Owner_Name"))
                lst.SubItems.Add(dr.Item("Phone_Number"))
                lst.SubItems.Add(dr.Item("Date"))
                lst.SubItems.Add(dr.Item("Time"))
                lst.SubItems.Add(dr.Item("Status"))

                ListView1.Items.Add(lst)
            End While
            dr.Close()

        Catch ex As Exception
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally

        End Try

    End Sub
    Private Sub park_updata_data()
        Try

            SQLStatement = "UPDATE parking SET Owner_Name ='" & txtOname.Text & "',Registration_No ='" & txtregisNumber.Text & "',Phone_Number='" & txtphone.Text & "'
             ,Asset = '" & cbasset.Text & "', Status = '" & cbstatus.Text & "'
             WHERE Phone_Number = '" & txtphone.Text & "'"
            Saverecords(SQLStatement)

            MsgBox("Update Successful!")
            SQLStatement = "SELECT * FROM parking"
            park_load_data()

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
            lblPID.Text = ""
            lblOID.Text = ""
            cbasset.Text = ""
            txtregisNumber.Clear()
            lbldate.Text = ""
            lbltime.Text = ""
            txtOname.Clear()

            txtphone.Clear()
            cbstatus.Text = ""
        End Try
        Exit Sub
    End Sub
    Private Sub park_search_data()
        Try
            SQLStatement = "SELECT* FROM parking WHERE Owner_ID LIKE'" & txtsearch.Text & "%' OR Phone_Number LIKE'" & txtsearch.Text & "%' OR Registration_No LIKE'" & txtsearch.Text & "%' AND Date='" & System.DateTime.Now.ToString("dd/MM/yyyy") & "'"
            park_load_data()
        Catch ex As Exception
            MsgBox(ex.Message)
            txtsearch.Clear()
            txtsearch.Focus()
        Finally

        End Try
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        SQLStatement = "SELECT*  FROM parking"
        check_data()
    End Sub
    Private Sub check_data()
        Try


            Dim Command = New MySqlCommand(SQLStatement, SQLconnection)
            dr = Command.ExecuteReader

            If dr.Read Then
                dr.Close()
                SQLStatement = "SELECT * FROM parking"
                park_load_data()
            Else
                dr.Close()
                MsgBox("No data found on the system!")


            End If

        Catch ex As Exception
            dr.Close()
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally
            '   
        End Try
    End Sub

    Private Sub txtsearch_TextChanged(sender As Object, e As EventArgs) Handles txtsearch.TextChanged
        park_search_data()
    End Sub

    Private Sub btnEdit_Click(sender As Object, e As EventArgs) Handles btnEdit.Click
        park_updata_data()
    End Sub

    Private Sub cbasset_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbasset.SelectedIndexChanged
        randomGen()
        lblPID.Text = "Park" & userid
        lblOID.Text = cbasset.Text & userid
    End Sub

    Private Sub systimer_Tick(sender As Object, e As EventArgs) Handles systimer.Tick
        lbldate.Text = System.DateTime.Now.ToString("dd/MM/yyyy")
        lbltime.Text = System.DateTime.Now.ToString("HH:MM:ss")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        staff.Show()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        SignupScreen.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Hide()
        loginscreen.Show()
    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub
End Class