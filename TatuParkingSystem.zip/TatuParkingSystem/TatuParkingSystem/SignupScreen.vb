﻿Imports MySql.Data.MySqlClient

Public Class SignupScreen

    Dim MyString As String = "Server=localhost;user id = root;password = '';Database = tatuDB;Port=3306 "
    Dim SQLconnection As MySqlConnection = New MySqlConnection
    Dim SQLStatement As String
    Dim dr As MySqlDataReader
    Dim sda As MySqlDataAdapter
    Dim table As DataTable

    Dim userid As Integer
    Private Sub SignupScreen_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If (SQLconnection.State = ConnectionState.Open) Then
            SQLStatement = "SELECT * FROM useracount"
            acounts_load_data()

        Else
            SQLconnection.ConnectionString = MyString
            SQLconnection.Open()
            SQLStatement = "SELECT * FROM useracount"
            acounts_load_data()
        End If
        'SQLconnection.Open()
    End Sub
    Private Sub randomGen()
        Dim randoms(1234) As Integer
        Dim Random_Number As Random = New Random()
        userid = Random_Number.Next()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Hide()
        activity.Show()
    End Sub

    Private Sub btncreate_Click(sender As Object, e As EventArgs) Handles btncreate.Click

        If txtfullname.Text = "" Then
            MsgBox("Please the field cannot be empty")

        ElseIf txtphone.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtemail.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtpassword.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtconfimpassword.Text = "" Then
            MsgBox("Please the field cannot be empty")
        ElseIf txtphone.Text = "" Then
            MsgBox("Please the field cannot be empty")

        Else
            randomGen()
            account_check()

            Try
                If txtphone.Text <> "" Then
                    SQLStatement = " INSERT INTO useracount(User_ID,Full_Name,Phone_Number,Email,Password)
                                  VALUES('" & userid & "','" & txtfullname.Text & "', '" & txtphone.Text & "','" & txtemail.Text & "','" & txtpassword.Text & "')"
                    Saverecords(SQLStatement)
                    MsgBox("Account Created Successful")

                    SQLStatement = "SELECT * FROM useracount"
                    acounts_load_data()
                Else

                End If
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                '
                txtphone.Clear()
                txtpassword.Clear()
                txtemail.Clear()

                txtconfimpassword.Clear()
                txtphone.Clear()

            End Try

        End If

    End Sub

    Private Sub Saverecords(ByRef SQLStatement As String)
        Try

            Dim cmd As MySqlCommand = New MySqlCommand
            With cmd
                .CommandText = SQLStatement
                .CommandType = CommandType.Text
                .Connection = SQLconnection
                .ExecuteNonQuery()
            End With


        Catch ex As Exception
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()
            Else
                MsgBox(ex.Message)
            End If

        End Try
    End Sub


    Private Sub acounts_load_data()

        Try
            ListView1.Items.Clear()

            Dim command As New MySqlCommand(SQLStatement, SQLconnection)
            dr = command.ExecuteReader
            While dr.Read

                Dim i As Integer
                Dim lst As New ListViewItem(i)

                lst.SubItems.Add(dr.Item("User_ID"))
                lst.SubItems.Add(dr.Item("Full_Name"))
                lst.SubItems.Add(dr.Item("Phone_Number"))
                lst.SubItems.Add(dr.Item("Email"))
                lst.SubItems.Add(dr.Item("Password"))
                ListView1.Items.Add(lst)
            End While
            dr.Close()

        Catch ex As Exception
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally

        End Try

    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        accouts_delete_data()
    End Sub
    Private Sub accouts_delete_data()
        If txtphone.Text <> "" Then
            txtphone.Text = ListView1.SelectedItems(0).SubItems(3).Text

            Dim msg As Integer
            msg = MsgBox("Are You Sure You Want Delete This Account", vbYesNo + vbQuestion, "Information Deleting")

            If msg = 6 Then
                SQLStatement = "DELETE FROM useracount Where Phone_Number = '" & ListView1.SelectedItems(0).SubItems(3).Text & "'"
                Try
                    Saverecords(SQLStatement)
                    MsgBox("Account Deleted Successful")
                    SQLStatement = "SELECT * FROM useracount"
                    acounts_load_data()
                Catch ex As Exception
                Finally
                End Try
            End If
        Else
            MsgBox("Select the row you want to delete! ")

        End If
    End Sub
    Private Sub txtphone_TextChanged(sender As Object, e As EventArgs) Handles txtphone.TextChanged

    End Sub
    Private Sub txtphone_GotFocus(sender As Object, e As EventArgs) Handles txtphone.GotFocus
        If txtpassword.Text <> txtconfimpassword.Text Then

            txtconfimpassword.Focus()
            txtconfimpassword.Clear()
            txtconfimpassword.ForeColor = Color.Red

        ElseIf txtpassword.Text = "" Then
            txtconfimpassword.ForeColor = Color.Navy
        Else
            txtconfimpassword.ForeColor = Color.LawnGreen
        End If

    End Sub

    Private Sub accout_updata_data()
        Try

            SQLStatement = "UPDATE useracount SET Full_Name ='" & txtfullname.Text & "', Phone_Number = '" & txtphone.Text & "', Email = '" & txtemail.Text & "'
            , Password = '" & txtpassword.Text & "'  WHERE Phone_Number = '" & txtphone.Text & "'"
            Saverecords(SQLStatement)

            MsgBox("Update Successful!")
            SQLStatement = "SELECT * FROM useracount"
            acounts_load_data()
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

            txtphone.Clear()
            txtpassword.Clear()
            txtemail.Clear()

            txtconfimpassword.Clear()
            txtphone.Clear()
        End Try
        Exit Sub
    End Sub

    Private Sub account_check()
        Try

            SQLStatement = "SELECT Email,Phone_Number FROM useracount WHERE Email ='" & txtemail.Text & "' OR Phone_Number ='" & txtphone.Text & "'"
            Dim Command = New MySqlCommand(SQLStatement, SQLconnection)
            dr = Command.ExecuteReader

            If dr.Read Then
                dr.Close()
                MsgBox("Account already exist")
                Exit Sub
            Else
                dr.Close()
                'MsgBox("Account not found on the system! check the the User Name")


            End If

        Catch ex As Exception
            dr.Close()
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally
            '   
        End Try
    End Sub
    Private Sub check_data()
        Try


            Dim Command = New MySqlCommand(SQLStatement, SQLconnection)
            dr = Command.ExecuteReader

            If dr.Read Then
                dr.Close()
                SQLStatement = "SELECT * FROM useracount"
                acounts_load_data()
            Else
                dr.Close()
                MsgBox("No data found on the system!")


            End If

        Catch ex As Exception
            dr.Close()
            Dim exms As String
            exms = ex.Message
            If exms = "Connection must be valid and open." Or exms = "Fatal error encountered during command execution." Or exms = "Unable to write data to the transport connection: An existing connection was forcibly closed by the remote host." Or exms = "Unable to connect to any of the specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Or exms = "Unable to write data to the transport connection: An existing connection was forcily closed by the remote host." Or exms = "Unable to connect to any of the Specified MySQL hosts." Then
                SQLconnection.ConnectionString = MyString
                SQLconnection.Open()

            Else
                MsgBox(ex.Message)
            End If
        Finally
            '   
        End Try
    End Sub
    Private Sub account_search_data()
        Try
            SQLStatement = "SELECT* FROM useracount WHERE User_ID LIKE'" & txtsearch.Text & "%' OR Phone_Number LIKE'" & txtsearch.Text & "%'"
            acounts_load_data()
        Catch ex As Exception
            MsgBox(ex.Message)
            txtsearch.Clear()
            txtsearch.Focus()
        Finally

        End Try
    End Sub

    Private Sub btnupdate_Click(sender As Object, e As EventArgs) Handles btnupdate.Click
        accout_updata_data()
    End Sub

    Private Sub txtsearch_TextChanged(sender As Object, e As EventArgs) Handles txtsearch.TextChanged
        account_search_data()
    End Sub

    Private Sub btnrefresh_Click(sender As Object, e As EventArgs) Handles btnrefresh.Click
        SQLStatement = "SELECT*  FROM useracount"
        check_data()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged

    End Sub

    Private Sub ListView1_Click(sender As Object, e As EventArgs) Handles ListView1.Click
        txtfullname.Text = Me.ListView1.SelectedItems(0).SubItems(2).Text
        txtphone.Text = Me.ListView1.SelectedItems(0).SubItems(3).Text
        txtemail.Text = Me.ListView1.SelectedItems(0).SubItems(4).Text
        txtpassword.Text = Me.ListView1.SelectedItems(0).SubItems(5).Text
        txtconfimpassword.Text = Me.ListView1.SelectedItems(0).SubItems(5).Text


    End Sub


End Class