﻿Imports MySql.Data.MySqlClient
Public Class loginscreen
    Dim MyString As String = "Server=localhost;user id = root;password = '';Database = tatuDB;Port=3306 "
    Dim SQLconnection As MySqlConnection = New MySqlConnection
    Dim SQLStatement As String
    Dim dr As MySqlDataReader
    Dim sda As MySqlDataAdapter
    Dim table As DataTable
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If (SQLconnection.State = ConnectionState.Open) Then

        Else
            SQLconnection.ConnectionString = MyString
            SQLconnection.Open()


        End If
    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click

        If txtphone.Text = "" Then

            Label6.Text = ("Please the field cannot be empty")
            Label6.ForeColor = Color.Red
            BunifuTransition1.ShowSync(Panel3)
            Timer1.Start()
        ElseIf txtpassword.Text = "" Then

            Label6.Text = ("Please the field cannot be empty")
            Label6.ForeColor = Color.Red
            BunifuTransition1.ShowSync(Panel3)
            Timer1.Start()
        Else

            Try
                SQLStatement = "SELECT Email,Phone_Number,Password FROM useracount WHERE Phone_Number='" & txtphone.Text & "' AND Password='" & txtpassword.Text & "'"
                Dim Command = New MySqlCommand(SQLStatement, SQLconnection)
                dr = Command.ExecuteReader

                If dr.Read Then
                    dr.Close()
                    Label6.Text = ("Login successful")

                    BunifuTransition1.ShowSync(Panel3)
                    Timer1.Start()
                    activity.Show()

                Else
                    dr.Close()
                    Label6.Text = (" User Login failed")
                    Label6.ForeColor = Color.Red
                    BunifuTransition1.ShowSync(Panel3)
                    Timer1.Start()



                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                '
                txtphone.Clear()
                txtpassword.Clear()


            End Try

        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        BunifuTransition1.HideSync(Panel3)
        Timer1.Stop()
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click
        resetpassword.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
